public class CBNode
{
	public char label;
	public char character;
	public CBNode left;
	public CBNode right;
}
