import java.util.Scanner;

public class LLStringTest_asjfg
{
	public static void main(String[] ar)
	{
		Scanner sc = new Scanner(System.in);
		int test = sc.nextInt();
		switch (test) {
			case 1:
				TEST1_tonatnjtaknjawe.test();
				break;
			case 2:
				TEST2_tonatnjtaknjawe.test();
				break;
			case 3:
				TEST3_tonatnjtaknjawe.test();
				break;
		}
	}
}

